# Bible Reading Tracker

A small PWA created from `Life Dashboard 4.5.xlsx`.

## Included
- 66 Bible books / 1,189 chapters
- Per-book progress
- Daily reading journal
- “What did I learn?” notes
- JSON backup/import
- Offline-first local storage
- Optional cross-device sync through **Apache CouchDB**, an open-source database

## Run locally
Because browsers restrict some local-file features, serve this folder over HTTP:

```bash
python3 -m http.server 8080
```

Then open `http://localhost:8080`.

## Self-host sync
1. Install Docker.
2. Run `docker compose up -d`.
3. Put your CouchDB server URL in the app's Sync tab.
4. Enter the database name and CouchDB credentials.
5. Press **Connect & sync**.

For a real internet deployment, put CouchDB behind HTTPS and configure CouchDB CORS to allow your website origin. Do not expose an unauthenticated CouchDB instance.

## Deploy the website
The frontend is static, so it can be hosted on GitHub Pages, Cloudflare Pages, Netlify, or any normal web server. The sync database can remain on your own server.

## Important
The initial workbook data is imported as starting progress. The tracker preserves the workbook's 66-book structure and 1,189-chapter target. The exact chapter-level history cannot always be inferred from free-text entries, so the app lets you correct chapter completion directly.
