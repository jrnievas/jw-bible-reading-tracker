window.BIBLE_DATA = {
  "books": [
    {
      "name": "Genesis",
      "chapters": 50,
      "initialRead": 0
    },
    {
      "name": "Exodus",
      "chapters": 40,
      "initialRead": 0
    },
    {
      "name": "Leviticus",
      "chapters": 27,
      "initialRead": 0
    },
    {
      "name": "Bilang",
      "chapters": 36,
      "initialRead": 0
    },
    {
      "name": "Deuteronomio",
      "chapters": 34,
      "initialRead": 0
    },
    {
      "name": "Josue",
      "chapters": 24,
      "initialRead": 0
    },
    {
      "name": "Hukom",
      "chapters": 21,
      "initialRead": 0
    },
    {
      "name": "Ruth",
      "chapters": 4,
      "initialRead": 0
    },
    {
      "name": "1 Samuel",
      "chapters": 31,
      "initialRead": 0
    },
    {
      "name": "2 Samuel",
      "chapters": 24,
      "initialRead": 0
    },
    {
      "name": "1 Hari",
      "chapters": 22,
      "initialRead": 0
    },
    {
      "name": "2 Hari",
      "chapters": 25,
      "initialRead": 0
    },
    {
      "name": "1 Cronica",
      "chapters": 29,
      "initialRead": 0
    },
    {
      "name": "2 Cronica",
      "chapters": 36,
      "initialRead": 0
    },
    {
      "name": "Ezra",
      "chapters": 10,
      "initialRead": 0
    },
    {
      "name": "Nehemias",
      "chapters": 13,
      "initialRead": 0
    },
    {
      "name": "Esther",
      "chapters": 10,
      "initialRead": 0
    },
    {
      "name": "Job",
      "chapters": 42,
      "initialRead": 0
    },
    {
      "name": "Awit",
      "chapters": 150,
      "initialRead": 0
    },
    {
      "name": "Kawikaan",
      "chapters": 31,
      "initialRead": 3
    },
    {
      "name": "Eclesiastes",
      "chapters": 12,
      "initialRead": 0
    },
    {
      "name": "Awit ni Solomon",
      "chapters": 8,
      "initialRead": 3
    },
    {
      "name": "Isaias",
      "chapters": 66,
      "initialRead": 0
    },
    {
      "name": "Jeremias",
      "chapters": 52,
      "initialRead": 26
    },
    {
      "name": "Panaghoy",
      "chapters": 5,
      "initialRead": 0
    },
    {
      "name": "Ezekiel",
      "chapters": 48,
      "initialRead": 0
    },
    {
      "name": "Daniel",
      "chapters": 12,
      "initialRead": 0
    },
    {
      "name": "Oseas",
      "chapters": 14,
      "initialRead": 14
    },
    {
      "name": "Joel",
      "chapters": 3,
      "initialRead": 3
    },
    {
      "name": "Amos",
      "chapters": 9,
      "initialRead": 9
    },
    {
      "name": "Obadias",
      "chapters": 1,
      "initialRead": 0
    },
    {
      "name": "Jonas",
      "chapters": 4,
      "initialRead": 4
    },
    {
      "name": "Mikas",
      "chapters": 7,
      "initialRead": 0
    },
    {
      "name": "Nahum",
      "chapters": 3,
      "initialRead": 0
    },
    {
      "name": "Habakuk",
      "chapters": 3,
      "initialRead": 0
    },
    {
      "name": "Zefanias",
      "chapters": 3,
      "initialRead": 0
    },
    {
      "name": "Hagai",
      "chapters": 2,
      "initialRead": 0
    },
    {
      "name": "Zacarias",
      "chapters": 14,
      "initialRead": 0
    },
    {
      "name": "Malakias",
      "chapters": 4,
      "initialRead": 0
    },
    {
      "name": "Mateo",
      "chapters": 28,
      "initialRead": 0
    },
    {
      "name": "Marcos",
      "chapters": 16,
      "initialRead": 0
    },
    {
      "name": "Lucas",
      "chapters": 24,
      "initialRead": 0
    },
    {
      "name": "Juan",
      "chapters": 21,
      "initialRead": 0
    },
    {
      "name": "Gawa",
      "chapters": 28,
      "initialRead": 0
    },
    {
      "name": "Roma",
      "chapters": 16,
      "initialRead": 0
    },
    {
      "name": "1 Corinto",
      "chapters": 16,
      "initialRead": 0
    },
    {
      "name": "2 Corinto",
      "chapters": 13,
      "initialRead": 0
    },
    {
      "name": "Galacia",
      "chapters": 6,
      "initialRead": 2
    },
    {
      "name": "Efeso",
      "chapters": 6,
      "initialRead": 0
    },
    {
      "name": "Filipos",
      "chapters": 4,
      "initialRead": 0
    },
    {
      "name": "Colosas",
      "chapters": 4,
      "initialRead": 0
    },
    {
      "name": "1 Tesalonica",
      "chapters": 5,
      "initialRead": 0
    },
    {
      "name": "2 Tesalonica",
      "chapters": 3,
      "initialRead": 0
    },
    {
      "name": "1 Timoteo",
      "chapters": 6,
      "initialRead": 0
    },
    {
      "name": "2 Timoteo",
      "chapters": 4,
      "initialRead": 0
    },
    {
      "name": "Tito",
      "chapters": 3,
      "initialRead": 0
    },
    {
      "name": "Filemon",
      "chapters": 1,
      "initialRead": 0
    },
    {
      "name": "Hebreo",
      "chapters": 13,
      "initialRead": 0
    },
    {
      "name": "Santiago",
      "chapters": 5,
      "initialRead": 0
    },
    {
      "name": "1 Pedro",
      "chapters": 5,
      "initialRead": 0
    },
    {
      "name": "2 Pedro",
      "chapters": 3,
      "initialRead": 0
    },
    {
      "name": "1 Juan",
      "chapters": 5,
      "initialRead": 0
    },
    {
      "name": "2 Juan",
      "chapters": 1,
      "initialRead": 0
    },
    {
      "name": "3 Juan",
      "chapters": 1,
      "initialRead": 0
    },
    {
      "name": "Judas",
      "chapters": 1,
      "initialRead": 0
    },
    {
      "name": "Apocalipsis",
      "chapters": 22,
      "initialRead": 0
    }
  ],
  "dailyEntries": [
    [
      "2025-08-24",
      "Yes",
      1,
      "Joel Chapter 1",
      ""
    ],
    [
      "2025-08-25",
      "Yes",
      1,
      "Kawikaan 30",
      ""
    ],
    [
      "2025-08-26",
      "Yes",
      1,
      "Kawikaan 31",
      ""
    ],
    [
      "2025-08-27",
      "Yes",
      4,
      "Re-reading of Kawikaan 30; Read Awit ni Solomon 1-3",
      ""
    ],
    [
      "2025-08-28",
      "Yes",
      1,
      "Galacia 1; 2:1-14",
      ""
    ],
    [
      "2025-08-29",
      "Yes",
      2,
      "Joel 2-3",
      ""
    ],
    [
      "2025-08-30",
      "Yes",
      1,
      "Amos 1;",
      ""
    ]
  ],
  "meta": {
    "source": "Life Dashboard 4.5.xlsx",
    "targetChapters": 1189
  }
};
