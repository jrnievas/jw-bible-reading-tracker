const KEY="bibleTracker.v1";
const state=JSON.parse(localStorage.getItem(KEY)||"null")||{
  books:window.BIBLE_DATA.books.map(b=>({name:b.name,chapters:b.chapters,done:Array.from({length:b.initialRead},(_,i)=>i+1)})),
  entries:window.BIBLE_DATA.dailyEntries.map(x=>({date:x[0],status:x[1],chapters:x[2],reading:x[3],learned:x[4]}))
};
let db=null,remote=null;
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
function save(){localStorage.setItem(KEY,JSON.stringify(state));render();}
function toast(t){const e=$("#toast");e.textContent=t;e.classList.add("show");setTimeout(()=>e.classList.remove("show"),1800)}
function total(){return state.books.reduce((a,b)=>a+b.chapters,0)}
function read(){return state.books.reduce((a,b)=>a+b.done.length,0)}
function render(){
 const p=Math.round(read()/total()*100); $("#pct").textContent=p+"%"; $("#summary").textContent=`${read().toLocaleString()} of ${total().toLocaleString()} chapters completed`;
 $("#bar").style.width=p+"%"; $(".progress-ring").style.setProperty("--progress",p+"%");
 $("#daysRead").textContent=state.entries.filter(e=>e.status==="Yes").length;
 $("#booksStarted").textContent=state.books.filter(b=>b.done.length).length;
 $("#booksFinished").textContent=state.books.filter(b=>b.done.length>=b.chapters).length;
 renderBooks(); renderHistory(); renderChapters();
}
function renderBooks(){
 const q=$("#bookSearch").value.toLowerCase(), t=$("#testament").value;
 $("#bookList").innerHTML=state.books.map((b,i)=>{
   const greek=i>=39, pct=Math.round(b.done.length/b.chapters*100);
   if(q&&!b.name.toLowerCase().includes(q))return "";
   if(t==="hebrew"&&greek||t==="greek"&&!greek)return "";
   return `<div class="book"><div class="book-top"><span>${b.name}</span><span>${b.done.length}/${b.chapters}</span></div><div class="mini-bar"><i style="width:${pct}%"></i></div><small class="muted">${pct}% complete</small></div>`;
 }).join("");
}
function renderChapters(){
 const b=state.books[$("#bookSelect").selectedIndex]||state.books[0];
 const doneSet=new Set(b.done);
 $("#chapterGrid").innerHTML=Array.from({length:b.chapters},(_,i)=>{
   const ch=i+1;
   return `<button class="chapter${doneSet.has(ch)?" done":""}" data-ch="${ch}">${ch}</button>`;
 }).join("");
 $$("#chapterGrid .chapter").forEach(x=>x.onclick=()=>toggleChapter(+x.dataset.ch));
}
function toggleChapter(ch){
 const b=state.books[$("#bookSelect").selectedIndex], idx=b.done.indexOf(ch);
 if(idx>=0)b.done.splice(idx,1); else b.done.push(ch);
 b.done.sort((a,b)=>a-b); save(); toast(`${b.name} chapter ${ch} ${idx>=0?"unchecked":"completed"}`);
}
function renderHistory(){
 const q=$("#historySearch").value.toLowerCase();
 $("#historyList").innerHTML=state.entries.slice().sort((a,b)=>b.date.localeCompare(a.date)).filter(e=>(e.reading||"").toLowerCase().includes(q)||(e.learned||"").toLowerCase().includes(q)).map(e=>`<div class="history-item"><b>${e.date} · ${e.chapters||0} chapter${e.chapters==1?"":"s"}</b><div>${esc(e.reading||"No reading description")}</div>${e.learned?`<small>${esc(e.learned)}</small>`:""}</div>`).join("")||'<div class="card muted">No matching entries.</div>';
}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}
function init(){
 $("#bookSelect").innerHTML=state.books.map(b=>`<option>${b.name}</option>`).join("");
 $("#todayDate").textContent=new Date().toISOString().slice(0,10);
 render();
 $$(".tab").forEach(btn=>btn.onclick=()=>{$$(".tab").forEach(x=>x.classList.remove("active"));btn.classList.add("active");$$(".panel").forEach(x=>x.classList.remove("active"));$("#"+btn.dataset.tab).classList.add("active")});
 $("#bookSelect").onchange=renderChapters; $("#bookSearch").oninput=renderBooks; $("#testament").onchange=renderBooks; $("#historySearch").oninput=renderHistory;
 $("#saveEntry").onclick=saveEntry; $("#exportBtn").onclick=exportData; $("#importFile").onchange=importData;
 $("#connectBtn").onclick=connect; $("#disconnectBtn").onclick=disconnect; $("#syncBtn").onclick=sync;
}
function saveEntry(){
 const date=$("#todayDate").textContent, existing=state.entries.find(e=>e.date===date);
 const b=state.books[$("#bookSelect").selectedIndex], selected=[...$("#chapterGrid .done")].map(x=>+x.dataset.ch);
 const entry={date,status:"Yes",chapters:selected.length,reading:$("#readingInput").value,learned:$("#learnedInput").value};
 if(existing)Object.assign(existing,entry); else state.entries.push(entry);
 save(); toast("Today's reading saved.");
}
function exportData(){
 const blob=new Blob([JSON.stringify(state,null,2)],{type:"application/json"}), a=document.createElement("a");
 a.href=URL.createObjectURL(blob);a.download="bible-reading-backup.json";a.click();URL.revokeObjectURL(a.href);
}
function importData(ev){
 const f=ev.target.files[0];if(!f)return;const r=new FileReader();
 r.onload=()=>{try{const x=JSON.parse(r.result);if(!x.books||!x.entries)throw Error();state.books=x.books;state.entries=x.entries;save();toast("Backup imported.");}catch{toast("Invalid backup file.")}};r.readAsText(f);
}
async function connect(){
 const url=$("#couchUrl").value.trim().replace(/\/$/,""), name=$("#couchDb").value.trim(), user=$("#couchUser").value, pass=$("#couchPass").value;
 if(!url||!name){toast("Enter a CouchDB URL and database.");return}
 remote={url,name,user,pass}; localStorage.setItem("bibleSyncConfig",JSON.stringify({url,name,user}));
 db=new PouchDB(name,{skip_setup:true});
 $("#syncStatus").textContent="Connecting…";$("#syncStatus").className="status";
 try{
   await db.info();
   const doc=await db.get("tracker-state").catch(e=>e.status===404?null:Promise.reject(e));
   if(doc?.state){Object.assign(state,doc.state);localStorage.setItem(KEY,JSON.stringify(state));render();}
   await db.put({_id:"tracker-state",state,_source:"Bible Reading Tracker",updatedAt:new Date().toISOString()}).catch(async e=>{
     if(e.status===409){const d=await db.get("tracker-state");d.state=state;d.updatedAt=new Date().toISOString();await db.put(d)}
     else throw e;
   });
   $("#syncStatus").textContent="Synced to CouchDB";$("#syncStatus").className="status ok";toast("Sync connected.");
 }catch(e){$("#syncStatus").textContent="Sync failed: "+(e.message||e);$("#syncStatus").className="status err";toast("Could not connect.");}
}
async function sync(){
 if(!db){toast("Connect a sync server first.");return}
 try{
   const d=await db.get("tracker-state");d.state=state;d.updatedAt=new Date().toISOString();await db.put(d);
   $("#syncStatus").textContent="Synced just now";$("#syncStatus").className="status ok";toast("Synced.");
 }catch(e){toast("Sync failed.");}
}
function disconnect(){db=null;remote=null;$("#syncStatus").textContent="Local-only mode";$("#syncStatus").className="status";toast("Disconnected. Local data is safe.");}
const cfg=JSON.parse(localStorage.getItem("bibleSyncConfig")||"null");if(cfg){$("#couchUrl").value=cfg.url||"";$("#couchDb").value=cfg.name||"bible-reading";$("#couchUser").value=cfg.user||"";}
init();
